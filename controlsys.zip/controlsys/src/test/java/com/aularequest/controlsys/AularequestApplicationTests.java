package com.aularequest.controlsys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AularequestApplicationTests {

	@Test
	void contextLoads() {
	}

}
